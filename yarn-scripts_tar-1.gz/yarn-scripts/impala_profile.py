#!/usr/bin/env python

from datetime import datetime, timedelta
from getpass import getpass
from optparse import OptionParser
from urllib import quote
import json
import logging
import random
import re
import requests
import sha
import sys
import warnings
import yaml

logging.basicConfig()
LOG = logging.getLogger(sys.argv[0])

VALID_FORMATS = ['text','html','thrift_encoded']

NODES = yaml.load("""
- AGGREGATION_NODE \(.*\)
- Averaged Fragment F[0-9]*
- BlockMgr
- CodeGen
- Coordinator Fragment F[0-9]*
- DataStreamSender \(.*\)
- EXCHANGE_NODE \(.*\)
- Execution Profile [a-f0-9]*:[a-f0-9]*
- Fragment F[0-9]*
- HASH_JOIN_NODE \(.*\)
- HDFS_SCAN_NODE \(.*\)
- HdfsTableSink
- ImpalaServer
- Instance [a-f0-9]*:[a-f0-9]* \(.*\)
- Query \(.*\)
- Summary
""")

class ContainerNode:
  def __init__(self, title):
    self.title = title
    self.nodes = []

  def append_node(self, node):
    self.nodes.append(node)

  def is_container(self):
    return True

  def __repr__(self):
    return 'ContainerNode[%s] - %d sections' % (self.title, len(self.nodes))

  def __str__(self):
    if self.title.startswith('Query'):
      ret = '''
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
    .text-section {{font-family:monospace;white-space:pre}}
    .list-group-item {{padding:5px;line-height:normal;font-size:9pt}}
    .panel-group {{margin:0}}
    .profile-code {{font-size:8pt;margin-left:40px}}
  </style>
</head>
<body>
<div class="container">
  <button id="btn-expand-all" type="button" class="btn btn-primary">Expand all</button>
  <button id="btn-collapse-all" type="button" class="btn btn-primary">Collapse all</button>
'''.format(title=self.title)
    else:
      ret = ''

    ret = ret + '''
  <div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" href="#collapse-{id}">{title}</a>
        </h4>
      </div>
      <div id="collapse-{id}" class="panel-collapse collapse">
        <ul class="list-group">
'''.format(title=self.title, id='%.0f'%(random.random()*1000000000))

    for node in self.nodes:
      ret = ret + '         <li class="list-group-item">%s</li>' % (node,)

    ret = ret + '''
        </ul>
      </div>
    </div>
  </div>
'''

    if self.title.startswith('Query'):
      ret = ret + '''
</div>
<script language="javascript">
  $('#btn-expand-all').on('click', function (e) { $('.panel-collapse').collapse('show'); });
  $('#btn-collapse-all').on('click', function (e) { $('.panel-collapse').collapse('hide'); });
</script>
</body>
</html>
'''
    return ret

class TextNode:
  def __init__(self):
    self.text = []

  def append_line(self, line):
    self.text.append(line)

  def is_container(self):
    return False

  def is_empty(self):
    return len(self.text) == 0

  def __str__(self):
    return '<span class="text-section">%s</span>' % ('\n'.join(self.text),)

class ProfilePrinter:

  def __init__(self, username, password, cm_url):
    self.session = requests.Session()
    self.session.auth = (username, password)
    self.cm_url = cm_url.rstrip('/')
    self.current_sections = []

  def get(self, path):
    warnings.simplefilter('ignore')
    url = '%s%s' % (self.cm_url, path)
    LOG.debug('URL: %s' % (url,))
    r = self.session.get(url, verify=False)
    r.raise_for_status()
    return r.text
  
  def get_json(self, path):
    return json.loads(self.get(path))
  
  def timedelta_total_seconds(self, td):
    return int((td.microseconds + 0.0 + (td.seconds + td.days * 24 * 3600) * 10 ** 6) / 10 ** 6)
  
  def get_profile(self, query_id, format):
    service_type = 'IMPALA'
    api_endpoint_name = 'impalaQueries'
    collection_name = 'queries'

    if format == 'html':
      api_format = 'text'
    else:
      api_format = format

    # Get cluster and service details
    clusters_path = '/api/v12/clusters'
    cluster_name = quote(self.get_json(clusters_path)['items'][0]['name'])
    services_path = '/api/v12/clusters/%s/services' % (cluster_name,)
    services = self.get_json(services_path)
    service_names = map(lambda s: quote(s['name']), filter(lambda x: x['type'] == service_type, services['items']))
    profile = None
    for service_name in service_names:
      query_details_url = '/api/v12/clusters/%s/services/%s/%s/%s?format=%s' % (cluster_name, service_name, api_endpoint_name, query_id, api_format)
      try:
        profile = self.get_json(query_details_url)['details']
        break
      except requests.exceptions.HTTPError as e:
        if e.response.status_code == requests.codes.internal_server_error \
           and 'message' in e.response.json() \
           and e.response.json()['message'] == 'Unknown profile.':
          pass
        else:
          raise

    if profile is None:
      print 'ERROR: Query ID not found'
    elif format == 'thrift_encoded':
      print profile
    elif format == 'text':
      self.print_profile(profile)
    elif format == 'html':
      self.print_html(profile)
    else:
      raise Exception('Unknown format: %s' % (format,))

  def format_time(self, time_ms):
    if time_ms < 1000:
      time_str = '{0:,.3f}ms'.format(time_ms,)
    elif time_ms < 60000:
      time_str = '{0:,.3f}secs'.format(time_ms/1000,)
    else:
      secs = time_ms/1000
      time_str = '%dh %02dm %02ds' % (int(secs/3600), int((secs%3600)/60), secs%60)
    return time_str

  def print_profile(self, profile):
    for line in self.extend_profile(profile):
      print line

  def section_level(self, line):
    for header in NODES:
      m = re.match(r'( *)%s$'%(header,), line)
      if m is not None:
        return len(m.groups()[0])
    else:
      return -1

  def add_html_section(self, section, level):
    last = len(self.current_sections) - 1
    while last >= 0 and self.current_sections[last][0] >= level:
      self.current_sections.pop()
      last -= 1
    if last >= 0:
      self.current_sections[last][1].append_node(section)
    if section.is_container():
      self.current_sections.append((level, section))

  def print_html(self, profile):
    text = TextNode()
    last_lvl = -1
    for line in self.extend_profile(profile):
      lvl = self.section_level(line)
      if lvl < 0:
        m = re.match(r'( *(Sql Statement:|Plan:|ExecSummary:)) *(.*)', line)
        if m is not None:
          LOG.debug("GROUPS:%s" % (m.groups(),))
          line = '{0:s}<pre class="profile-code">{2:s}'.format(*m.groups())
        elif re.match(r' *(Estimated Per-Host Mem:|Coordinator:|Planner Timeline$)', line):
          line = '</pre>' + line
        text.append_line(line)
      else:
        if not text.is_empty():
          self.add_html_section(text, last_lvl+1)
          text = TextNode()
        self.add_html_section(ContainerNode(line.strip()), lvl)
        last_lvl = lvl
    if not text.is_empty():
      self.add_html_section(text, last_lvl+1)
    print self.current_sections[0][1]

  def extend_profile(self, profile):
    timeline = False
    for line in profile.split('\n'):
      m = re.match(r' *Start Time: *(.*[^ ]) *$', line)
      if m is not None:
        start_time = datetime.strptime(m.groups()[0][:26], '%Y-%m-%d %H:%M:%S.%f')
        yield line
        continue

      m = re.match(r' *End Time: *(.*[^ ]) *$', line)
      if m is not None:
        end_time = datetime.strptime(m.groups()[0][:26], '%Y-%m-%d %H:%M:%S.%f')
        yield line
        yield '    Elapsed Time: %s' % (self.format_time(1000*(end_time-start_time).total_seconds()),)
        continue

      if line.strip() in ['Query Timeline', 'Planner Timeline']:
        timeline = True
        prev_nanos = 0.0
        yield line
        continue

      if timeline:
        m = re.match(r'^([^:]*: *)([0-9]*)$', line)
      else:
        m = re.match(r'^([^:]*[^ ]Timer?[^a-zA-Z]*: *)([0-9]*)$', line)
   
      if m is None:
        timeline = False
        yield line
      else:
        groups = m.groups()
        nanos = float(groups[1])

        if timeline:
          time_ms = (nanos - prev_nanos) / 1000000
          prev_nanos = nanos
        else:
          time_ms = nanos / 1000000

        yield '{0:s}{1:,.3f}ms ({2:s})'.format(groups[0], nanos/1000000, self.format_time(time_ms))

if __name__ == '__main__':
  parser = OptionParser(
    usage='%prog <cm_host> <impala_query_id>')

  parser.add_option('--format', action='store', default='text',
                    dest='format',
                    help='Output format. Valid values are: %s. Default: text.' % (', '.join(VALID_FORMATS),))

  parser.add_option('--debug', action='store_true',
                    dest='debug',
                    help='Enable debugging output.')

  (options, args) = parser.parse_args()

  if options.format not in VALID_FORMATS:
    print 'ERROR: Valid format values are: %s.' % (', '.join(VALID_FORMATS),)
    exit(1)

  if options.debug:
    LOG.setLevel(logging.DEBUG)

  if len(args) != 2:
    parser.print_help()
    exit(1)

  sys.stderr.write('CM username: ')
  username = sys.stdin.readline().rstrip()
  password = getpass('Password: ')
  
  yt = ProfilePrinter(username, password, args[0])
  yt.get_profile(args[1], options.format)

