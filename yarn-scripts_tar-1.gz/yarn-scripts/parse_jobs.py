#!/usr/bin/env python

from datetime import datetime
from glob import glob
from optparse import OptionParser
import json
import logging
import md5
import numpy as np
import os
import pandas as pd
import re
import sys
import time
import yaml

logging.basicConfig()
LOG = logging.getLogger(sys.argv[0])

# Globals
FIELD_DELIM = ','
RECORD_DELIM = '\n'

# Load attributes config
YARN_COUNTER_NAMES = yaml.load("""
- elapsed_time
- stages
- instances
- maps_completed
- maps_total
- reduces_completed
- reduces_total
- counter:hive.created_files
- counter:org.apache.hadoop.mapreduce.filesystemcounter.file_bytes_read
- counter:org.apache.hadoop.mapreduce.filesystemcounter.file_bytes_written
- counter:org.apache.hadoop.mapreduce.filesystemcounter.hdfs_bytes_read
- counter:org.apache.hadoop.mapreduce.filesystemcounter.hdfs_bytes_written
- counter:org.apache.hadoop.mapreduce.filesystemcounter.s3a_bytes_read
- counter:org.apache.hadoop.mapreduce.filesystemcounter.s3a_bytes_written
- counter:org.apache.hadoop.mapreduce.filesystemcounter.s3n_bytes_read
- counter:org.apache.hadoop.mapreduce.filesystemcounter.s3n_bytes_written
- counter:org.apache.hadoop.mapreduce.jobcounter.data_local_maps
- counter:org.apache.hadoop.mapreduce.jobcounter.mb_millis_maps
- counter:org.apache.hadoop.mapreduce.jobcounter.mb_millis_reduces
- counter:org.apache.hadoop.mapreduce.jobcounter.millis_maps
- counter:org.apache.hadoop.mapreduce.jobcounter.millis_reduces
- counter:org.apache.hadoop.mapreduce.jobcounter.num_failed_maps
- counter:org.apache.hadoop.mapreduce.jobcounter.num_failed_reduces
- counter:org.apache.hadoop.mapreduce.jobcounter.num_killed_reduces
- counter:org.apache.hadoop.mapreduce.jobcounter.other_local_maps
- counter:org.apache.hadoop.mapreduce.jobcounter.rack_local_maps
- counter:org.apache.hadoop.mapreduce.jobcounter.slots_millis_maps
- counter:org.apache.hadoop.mapreduce.jobcounter.slots_millis_reduces
- counter:org.apache.hadoop.mapreduce.jobcounter.total_launched_maps
- counter:org.apache.hadoop.mapreduce.jobcounter.total_launched_reduces
- counter:org.apache.hadoop.mapreduce.jobcounter.vcores_millis_maps
- counter:org.apache.hadoop.mapreduce.jobcounter.vcores_millis_reduces
- counter:org.apache.hadoop.mapreduce.taskcounter.committed_heap_bytes
- counter:org.apache.hadoop.mapreduce.taskcounter.cpu_milliseconds
- counter:org.apache.hadoop.mapreduce.taskcounter.failed_shuffle
- counter:org.apache.hadoop.mapreduce.taskcounter.map_output_bytes
- counter:org.apache.hadoop.mapreduce.taskcounter.map_output_materialized_bytes
- counter:org.apache.hadoop.mapreduce.taskcounter.merged_map_outputs
- counter:org.apache.hadoop.mapreduce.taskcounter.physical_memory_bytes
- counter:org.apache.hadoop.mapreduce.taskcounter.reduce_input_groups
- counter:org.apache.hadoop.mapreduce.taskcounter.reduce_shuffle_bytes
- counter:org.apache.hadoop.mapreduce.taskcounter.shuffled_maps
- counter:org.apache.hadoop.mapreduce.taskcounter.spilled_records
- counter:org.apache.hadoop.mapreduce.taskcounter.split_raw_bytes
- counter:org.apache.hadoop.mapreduce.taskcounter.virtual_memory_bytes
- map_counter:org.apache.hadoop.mapreduce.filesystemcounter.file_bytes_read
- map_counter:org.apache.hadoop.mapreduce.filesystemcounter.file_bytes_written
- map_counter:org.apache.hadoop.mapreduce.filesystemcounter.hdfs_bytes_read
- map_counter:org.apache.hadoop.mapreduce.filesystemcounter.hdfs_bytes_written
- map_counter:org.apache.hadoop.mapreduce.filesystemcounter.s3a_bytes_read
- map_counter:org.apache.hadoop.mapreduce.filesystemcounter.s3a_bytes_written
- map_counter:org.apache.hadoop.mapreduce.filesystemcounter.s3n_bytes_read
- map_counter:org.apache.hadoop.mapreduce.filesystemcounter.s3n_bytes_written
- map_counter:org.apache.hadoop.mapreduce.taskcounter.committed_heap_bytes
- map_counter:org.apache.hadoop.mapreduce.taskcounter.cpu_milliseconds
- map_counter:org.apache.hadoop.mapreduce.taskcounter.failed_shuffle
- map_counter:org.apache.hadoop.mapreduce.taskcounter.physical_memory_bytes
- map_counter:org.apache.hadoop.mapreduce.taskcounter.spilled_records
- map_counter:org.apache.hadoop.mapreduce.taskcounter.split_raw_bytes
- map_counter:org.apache.hadoop.mapreduce.taskcounter.virtual_memory_bytes
- reduce_counter:org.apache.hadoop.mapreduce.filesystemcounter.file_bytes_read
- reduce_counter:org.apache.hadoop.mapreduce.filesystemcounter.file_bytes_written
- reduce_counter:org.apache.hadoop.mapreduce.filesystemcounter.hdfs_bytes_read
- reduce_counter:org.apache.hadoop.mapreduce.filesystemcounter.hdfs_bytes_written
- reduce_counter:org.apache.hadoop.mapreduce.filesystemcounter.s3a_bytes_read
- reduce_counter:org.apache.hadoop.mapreduce.filesystemcounter.s3a_bytes_written
- reduce_counter:org.apache.hadoop.mapreduce.filesystemcounter.s3n_bytes_read
- reduce_counter:org.apache.hadoop.mapreduce.filesystemcounter.s3n_bytes_written
- reduce_counter:org.apache.hadoop.mapreduce.taskcounter.committed_heap_bytes
- reduce_counter:org.apache.hadoop.mapreduce.taskcounter.cpu_milliseconds
- reduce_counter:org.apache.hadoop.mapreduce.taskcounter.failed_shuffle
- reduce_counter:org.apache.hadoop.mapreduce.taskcounter.physical_memory_bytes
- reduce_counter:org.apache.hadoop.mapreduce.taskcounter.spilled_records
- reduce_counter:org.apache.hadoop.mapreduce.taskcounter.split_raw_bytes
- reduce_counter:org.apache.hadoop.mapreduce.taskcounter.virtual_memory_bytes
""")

IMPALA_COUNTER_NAMES = yaml.load("""
- elapsed_time
- stages
- instances
- admission_wait
- bytes_streamed
- client_fetch_wait_time
- cm_cpu_milliseconds
- estimated_per_node_peak_memory
- hdfs_average_scan_range
- hdfs_bytes_read
- hdfs_bytes_read_from_cache
- hdfs_bytes_read_local
- hdfs_bytes_read_remote
- hdfs_bytes_read_short_circuit
- hdfs_bytes_skipped
- hdfs_scanner_average_bytes_read_per_second
- memory_accrual
- memory_aggregate_peak
- memory_per_node_peak
- memory_spilled
- planning_wait_time
- thread_cpu_time
- thread_network_receive_wait_time
- thread_network_send_wait_time
- thread_storage_wait_time
- thread_total_time
""")

def flatten(v):
  for i in v:
    if type(i) == list:
      for j in i:
        yield j
    else:
      yield i

def attr_names(obj, level=0):
  if type(obj) == dict:
    children_attrs = []
    for k,v in obj.items():
      value_attrs = attr_names(v, level+1)
      if value_attrs is None:
        children_attrs.append("%s" % (k,))
      else:
        children_attrs.append("%s:%s" % (k,value_attrs))
    if any(map(lambda x: x is not None, children_attrs)):
      if level == 0:
        return '{%s}' % (' '.join(sorted(children_attrs)),)
      else:
        return '{%s}' % (' '.join(sorted(children_attrs)),)
        #return '{*}'
    else:
      return '{}'
  elif type(obj) == list:
    children_attrs = map(lambda x: attr_names(x, level+1), obj)
    if any(map(lambda x: x is not None, children_attrs)):
      return '[%s]' % (' '.join(sorted(children_attrs)),)
    else:
      return None
  else:
    return None

def get_attr(obj, attr, default):
  if attr in obj:
    return obj[attr]
  else:
    return default

def expand_input(input):
  return flatten([ q for g in input for l in glob(g) for p in [ [l] if not os.path.isdir(l) else glob(l + '/*.json') ] for q in p ])

def process_input(input, output_name, impala):
  if impala:
    collection_name = 'queries'
    id_attribute = 'queryId'
    app_name = lambda a: a['attributes']['session_type'] if 'session_type' in a['attributes'] else 'unknown'
    user_name = lambda a: a['attributes']['original_user'] if 'original_user' in a['attributes'] else 'unknown'
    pool_name = lambda a: a['attributes']['pool'] if 'pool' in a['attributes'] else 'unknown'
    counter_names = IMPALA_COUNTER_NAMES
  else:
    collection_name = 'applications'
    id_attribute = 'applicationId'
    app_name = lambda a: a['name']
    user_name = lambda a: a['user']
    pool_name = lambda a: a['pool']
    counter_names = YARN_COUNTER_NAMES

  # Counters
  processed = 0
  duplicates = 0

  # Keep track of ids
  query_ids = {}
  users = {}
  pools = {}
  app_ids = set()

  # Output places
  queries_dir = output_name
  queries_file = output_name + '_queries.csv'
  queries_stats = output_name + '_stats.csv'
  if not os.path.exists(queries_dir):
    os.mkdir(queries_dir)

  # Create data frame for job counters
  stats = pd.DataFrame(columns=counter_names)
  
  # Open queries file
  qf = open(queries_file, 'w')
  qf.write(FIELD_DELIM.join(["SQL_ID","ELAPSED_TIME","SQL_FULLTEXT","USER","APP","REPORT"]) + RECORD_DELIM)
  
  now = time.time()
  for path in expand_input(input):
    print >> sys.stderr, "Processing file %s" % (path,)
    apps = json.load(open(path))
    for app in apps[collection_name]:
      id = app[id_attribute].encode('utf-8')
      name = app_name(app).encode('utf-8').replace('\n', '')
      user = user_name(app).encode('utf-8')
      pool = pool_name(app).encode('utf-8')
  
      # Process only Hive jobs
      attrs = app['attributes']
      if 'hive_query_id' in attrs:
        query_id = attrs['hive_query_id'].encode('utf-8')
        query_string = attrs['hive_query_string'].encode('utf-8')
      elif 'pig.script.id' in attrs:
        query_id = attrs['pig.script.id'].encode('utf-8')
        query_string = attrs['pig.cmd.args'].encode('utf-8')
      elif 'impala_version' in attrs:
        query_id = app['queryId'].encode('utf-8')
        query_string = app['statement'].encode('utf-8')
      else:
        query_id = id
        query_string = user + ' - ' + name
  
      # Check for duplicates
      if id in app_ids:
        duplicates += 1
        continue
      else:
        app_ids.add(id)
  
      # Increment job count
      processed += 1
      if processed % 1000 == 0:
        before = now
        now = time.time()
        print >> sys.stderr, "%d jobs processed: %.1fs for the last 1000" % (processed, now - before)
  
      # Calculate elapsed time, in milliseconds
      start_time = datetime.strptime(app['startTime'].replace('Z', '000'), '%Y-%m-%dT%H:%M:%S.%f')
      try:
        end_time = datetime.strptime(app['endTime'].replace('Z', '000'), '%Y-%m-%dT%H:%M:%S.%f')
      except:
        end_time = datetime.now()
      elapsed_time = int((end_time - start_time).total_seconds() * 1000)
    
      # Canonicalize query text
      stmt = query_string
      stmt = re.sub(r'\b([0-9][0-9.]*|\.[0-9.]+)\b', '##', stmt)
      stmt = re.sub(r'([\'"])[^\1]*?\1', '@@', stmt)
      stmt = re.sub(r'--[^\n]*', '', stmt)
      stmt = re.sub(r'\n', ' ', stmt)
      stmt = re.sub(r'\s+', ' ', stmt)
      stmt = stmt.lower()
  
      # Calculate query digest and save query to file
      digest = md5.md5(stmt).hexdigest()
      query_dir = os.path.join(queries_dir, digest)
      query_file = os.path.join(query_dir, query_id)
      if not os.path.exists(query_dir):
        os.mkdir(query_dir)
      if not os.path.exists(query_file):
        f = open(query_file, 'w')
        f.write('Query ID: %s\n' % (query_id,))
        f.write(query_string)
        f.close()
  
      # Save job data
      job_file = os.path.join(query_dir, '%s_%s.json' % (query_id, id))
      if not os.path.exists(job_file):
        f = open(job_file, 'w')
        json.dump(app, f, indent=2)
        f.close()
  
      # Keep track of some attributes for each digest (instances)
      if digest not in query_ids:
        new_instance = 1
        query_ids[digest] = set([query_id])
        users[digest] = set([user])
        pools[digest] = set([pool])
      else:
        if query_id in query_ids[digest]:
          new_instance = 0
        else:
          new_instance = 1
        query_ids[digest].add(query_id)
        users[digest].add(user)
        pools[digest].add(pool)
  
      # Add calculated metrics to attributes
      attrs.update({'elapsed_time': elapsed_time, 'stages':1, 'instances':new_instance})
      job_attrs = pd.Series(attrs)
      job_attrs = job_attrs[counter_names].astype('float')
      if digest not in stats.index:
        stats.loc[digest] = job_attrs
      else:
        stats.loc[digest] = stats.loc[digest].add(job_attrs, fill_value=0.0)
  
      # Add job to csv file
      line = FIELD_DELIM.join([
        '%s_%s' % (processed, query_id),
         str(elapsed_time),
         '"%s"' % (query_string.replace('"', '""'),),
         user, pool,
         '"%s"' % (name,)])
      qf.write(line + RECORD_DELIM)

  # Write user and pool files
  for digest in users:
    query_dir = os.path.join(queries_dir, digest)
    users_file = os.path.join(query_dir, 'users.txt')
    pools_file = os.path.join(query_dir, 'pools.txt')
    open(users_file, 'w').write(' '.join(sorted(users[digest])))
    open(pools_file, 'w').write(' '.join(sorted(pools[digest])))
  
  # Save stats csv
  open(queries_stats, 'w').write(stats.to_csv(float_format='%.0f'))
  qf.close()
  
  # Print some info
  print >> sys.stderr, "Processed:  %d" % (processed,)
  print >> sys.stderr, "Duplicates: %d" % (duplicates,)

if __name__ == '__main__':
  parser = OptionParser(
    usage='%prog <output_name> <input_dir_or_file> ...')

  parser.add_option('--impala', action='store_true',
                    dest='impala',
                    help='Parse Impala queries.')

  parser.add_option('--debug', action='store_true',
                    dest='debug',
                    help='Enable debugging output.')

  (options, args) = parser.parse_args()

  if options.debug:
    LOG.setLevel(logging.DEBUG)

  if len(args) < 2:
    parser.print_help()
    exit(1)

  # Arguments
  output_name = args[0]
  input = args[1:]

  process_input(input, output_name, options.impala)

