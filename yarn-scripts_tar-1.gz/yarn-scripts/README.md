# YARN scripts

## Prerequisites

These scripts can be executed on both MacOS and Linux.
The following software is required:
- Python 2.7
- Python packages:
    + cython (pandas' dependency)
    + numpy
    + pandas
    + pyyaml
    + requests

## fsck_stats.py

Calculates file size distribution for HDFS. This script takes the output of the ```hdfs fsck``` command on the standard input and produces a report with the file size distribution.

The basic usage is:

```
Usage: fsck_stats.py <base_dir> <level>

Options:
  -h, --help            show this help message and exit
  --one-line-report=THRESHOLD_BYTES
                        Small file threshold, in bytes
```

where:

**base_dir** is the base directory for which you want to calculate the file size distribution. For the entire HDFS contents, specify ```/```.

**level** is the depth, relative to ```base_dir``` that the script will use to aggregate the file statistics. For example, if ```level``` is 0 (zero), the file distribution will be aggregated for the specified ```base_dir```. If ```level``` is 1, the statistics will be aggregated for the child directories of ```base_dir```.

There are two types of reports. The basic report looks like the example below:

```
$ hdfs fsck / -files| python fsck_stats.py / 0

Directory: /
Count:       6,053,855
Total size:  248,532,562,449,947
Mean size:   41,053,603
Median size: 157,903
                              Bytes           Files        Pct     Running sum Running pct
                                  0         345,637        5.7         345,637        5.7
                             1 to 9          72,720        1.2         418,357        6.9
                           10 to 99         142,950        2.4         561,307        9.3
                         100 to 999         471,134        7.8       1,032,441       17.1
                     1,000 to 9,999         510,096        8.4       1,542,537       25.5
                   10,000 to 99,999         931,902       15.4       2,474,439       40.9
                 100,000 to 999,999       1,700,506       28.1       4,174,945       69.0
             1,000,000 to 9,999,999         755,303       12.5       4,930,248       81.4
           10,000,000 to 99,999,999         743,001       12.3       5,673,249       93.7
         100,000,000 to 999,999,999         321,060        5.3       5,994,309       99.0
     1,000,000,000 to 9,999,999,999          58,594        1.0       6,052,903      100.0
   10,000,000,000 to 99,999,999,999             935        0.0       6,053,838      100.0
 100,000,000,000 to 999,999,999,999              17        0.0       6,053,855      100.0
```

The one-line report lists the number of small files for each directory in the aggregation level. The small file threshold (in bytes) must be specified in the command line. The output is sort in descending order of the number of small files.

```
$ hdfs fsck / -files -blocks | python fsck_stats.py / 1 --one-line-report 10000000
directory                                                    median_sz_bytes smallfiles % of total files%
/user/                                                               136,134  2,176,108  81.7%
/data/                                                               156,588  2,004,448  77.6%
/tmp/                                                                221,522    749,687  93.2%
/misc-stage/                                                           8,545          5 100.0%
```

## get_jobs_data.py

Downloads data for completed **YARN or IMPALA** jobs from Cloudera Manager. The data is saved in JSON format. The script creates one file per hour, containing all the jobs completed during that hour. 

If the ```--impala``` option is specified the script will download **IMPALA** jobs. If that option is omitted, it will collect **YARN** jobs.

The script usage is:

```
Usage: get_jobs_data.py <cm_url> <output_dir> <start_time> <end_time>

Options:
  -h, --help  show this help message and exit
  --impala    Capture Impala queries.
  --debug     Enable debugging output.
```

where:

**cm_url** is the Cloudera Manager URL, in the form: ```http[s]://hostname:port``` 

**output_dir** is the directory where the JSON files will be saved. If the directory doesn't exist it will be created.

**start_time** is the start of the period for which we want to extract the job information. It must be expressed in the format YYYYMMDDHHMMSS.

**start_time** is the end of the period for which we want to extract the job information. It must be expressed in the format YYYYMMDDHHMMSS.

Example:
```
$ ./get_jobs_data.sh myworkload 20160927160000 20160927180000
CM username: admin
Password: 
2016-09-27T18:00:00.000Z:
   0 Total
2016-09-27T17:00:00.000Z:
   1 SUCCEEDED
   1 Total
2016-09-27T16:00:00.000Z:
   0 Total
$ ls -l myworkload/
total 720
-rw-r--r--  1 araujo  staff     46 Sep 27 09:48 2016-09-27T16:00:00.000Z.json
-rw-r--r--  1 araujo  staff  15216 Sep 27 09:48 2016-09-27T17:00:00.000Z.json
-rw-r--r--  1 araujo  staff     46 Sep 27 09:48 2016-09-27T18:00:00.000Z.json
```

## parse_jobs.py

Parses the output generated by the ```get_jobs_data.sh``` script and calculates aggregated statistics about queries execution. This script matches queries that are similar (same queries with different literal values) and aggregate statistics by each type of query.

When parsing **IMPALA** jobs logs the ```--impala``` option must be specified. For parsing **YARN** logs, omit that option.

The script usage is:
```
Usage: parse_jobs.py <output_name> <input_dir_or_file> ...

Options:
  -h, --help  show this help message and exit
  --impala    Parse Impala queries.
  --debug     Enable debugging output.
```

where:

**output_name** is the base name that will be used to created the output described below.

**input_dir_or_file** - multiple directories and/or JSON files can be specified as iput. Files will be loaded directly. If a directory is specified the script will load all the JSON files (those with a ```.json``` extension) found in the directory.

Three different outputs are generated by this script:

- The ```<output_name>``` directory, containing a subdirectory for each type of query. Each subdirectory contains 2 files for each query of this type:
    + One text file containing the original query statement
    + One JSON file with the job details for that particular query execution
- The ```<output_name>_queries.csv``` file - this is a CSV file containing one row for each executed query/job. This file is formatted in a way to allow uploads to Cloudera Navigator Optimizer. Each contains the following fields: ```SQL_ID``` ,```ELAPSED_TIME```, ```SQL_FULLTEXT```, ```USER```, ```APP```, ```REPORT```.
- The ```<output_name>_stats.csv``` file - this is a CSV file containing the one row for each type of query. Each row can be matched to one subdirectory under the ```<output_name>``` directory using the query digest value (first column). Most of the relevant jobs' counters are aggregated (summed) for each type of query. This file can be used to find the top resource consumers according to different criteria.

## browse_top.sh

This script is a convenience utility to browse queries that are the top resource consumers given a specific criteria.

The script usage is:
```
Usage: ./browse_top.sh <output_name> [number_of_queries]
```

where:

**output_name** is the same parameter passed to the ```parse_jobs.py``` script to parse the jobs files.

**number_of_queries** is the number of top queries to browse through

When the script is executed it will prompt the user for a criteria to use to sort the queries. The options will be displayed on the screen. Once the user selects an option the script will show, one at a time, the top queries with some aggregated statistics for it.

## yarn_top.py

Shows the jobs currently running on YARN, displaying resource usage per job. The list of jobs is sorted in descending order of the number of running containers.

Resource usage aggregated per YARN pool is also shown on screen. 

The script usage is:
```
Usage: yarn_top.py <cm_url>

Options:
  -h, --help      show this help message and exit
  --task-details  Show mapper/reducer tasks' details
```

where:

**cm_url** is the Cloudera Manager URL, in the form: ```http[s]://hostname:port``` 
