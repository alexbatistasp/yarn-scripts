#!/usr/bin/env python

from glob import glob
from optparse import OptionParser
import json
import logging
import os
import re
import sys
import time

logging.basicConfig()
LOG = logging.getLogger(sys.argv[0])

def flatten(v):
  for i in v:
    if type(i) == list:
      for j in i:
        yield j
    else:
      yield i

def attr_names(obj, level=0):
  if type(obj) == dict:
    children_attrs = []
    for k,v in obj.items():
      value_attrs = attr_names(v, level+1)
      if value_attrs is None:
        children_attrs.append("%s" % (k,))
      else:
        children_attrs.append("%s:%s" % (k,value_attrs))
    if any(map(lambda x: x is not None, children_attrs)):
      if level == 0:
        return '{%s}' % (' '.join(sorted(children_attrs)),)
      else:
        return '{%s}' % (' '.join(sorted(children_attrs)),)
        #return '{*}'
    else:
      return '{}'
  elif type(obj) == list:
    children_attrs = map(lambda x: attr_names(x, level+1), obj)
    if any(map(lambda x: x is not None, children_attrs)):
      return '[%s]' % (' '.join(sorted(children_attrs)),)
    else:
      return None
  else:
    return None

def get_attr(obj, attr, default):
  if attr in obj:
    return obj[attr]
  else:
    return default

def expand_input(input):
  return flatten([ q for g in input for l in glob(g) for p in [ [l] if not os.path.isdir(l) else glob(l + '/*.json') ] for q in p ])

def process_input(input, output_name, impala):
  if impala:
    collection_name = 'queries'
    id_attribute = 'queryId'
    app_name = lambda a: a['attributes']['session_type'] if 'session_type' in a['attributes'] else 'unknown'
    user_name = lambda a: a['attributes']['original_user'] if 'original_user' in a['attributes'] else 'unknown'
    pool_name = lambda a: a['attributes']['pool'] if 'pool' in a['attributes'] else 'unknown'
  else:
    collection_name = 'applications'
    id_attribute = 'applicationId'
    app_name = lambda a: a['name']
    user_name = lambda a: a['user']
    pool_name = lambda a: a['pool']

  # Keep track of ids
  errors = {}

  # Output places
  errors_file = output_name + '_errors.csv'

  now = time.time()
  for path in expand_input(input):
    print >> sys.stderr, "Processing file %s" % (path,)
    apps = json.load(open(path))
    for app in apps[collection_name]:
      id = app[id_attribute].encode('utf-8')
  
      attrs = app['attributes']
      state = app['queryState'].encode('utf-8')
      user = user_name(app).encode('utf-8')
      pool = pool_name(app).encode('utf-8')
      stats_missing = attrs['stats_missing'].encode('utf-8')
      admission_result = attrs['admission_result'].encode('utf-8')
      query_status = attrs['query_status'].encode('utf-8').replace('\n', '').replace('"', '').replace(',', '')
      query_status = re.sub(r'(invalid version number: ).*?(This could)', r'\1##. \2', query_status)

      if query_status == 'OK':
        status_type = 'OK'
      elif query_status == 'Cancelled':
        status_type = 'Cancelled'
      elif 'incompatible Parquet schema' in query_status:
        status_type = 'Invalid schema'
      elif 'AnalysisException' in query_status:
        status_type = 'AnalysisException'
      elif 'invalid compressed length' in query_status or 'Error seeking to' in query_status:
        status_type = 'Corrupt data'
      elif 'No mapping found for request from user' in query_status:
        status_type = 'User-pool mapping error'
      elif 'AlreadyExistsException' in query_status:
        status_type = 'AlreadyExistsException'
      elif 'TableNotFoundException' in query_status or 'Table/View does not exist' in query_status or 'table not found' in query_status:
        status_type = 'TableNotFoundException'
      elif 'AuthorizationException' in query_status:
        status_type = 'AuthorizationException'
      elif 'Connection refused' in query_status or 'Couldn\'t open transport' in query_status:
        status_type = 'Connection refused'
      elif 'TableLoadingException' in query_status:
        status_type = 'TableLoadingException'
      elif 'Session closed' in query_status:
        status_type = 'Session Closed'
      elif 'OutOfMemoryError' in query_status or 'Memory limit exceeded' in query_status or 'memory needed' in query_status:
        status_type = 'OutOfMemoryError'
      elif 'invalid version number' in query_status:
        status_type = 'Invalid file'
      elif 'Error reading from HDFS file: s3a' in query_status:
        status_type = 'S3 I/O error'
      elif 'Cancelled due to unreachable impalad' in query_status:
        status_type = 'Unreachable impalad'
      elif 'Admission for query exceeded timeout' in query_status:
        status_type = 'Admission timeout'
      elif 'expired due to client inactivity' in query_status:
        status_type = 'Expired due to client inactivity'
      elif 'No such file or directory' in query_status:
        status_type = 'No such file or directory'
      else:
        status_type = 'Other'

      error = (user, pool, stats_missing, admission_result, state, status_type, query_status)

      if error not in errors:
        errors[error] = 1
      else:
        errors[error] = errors[error] + 1

  # Save errors csv
  ef = open(errors_file, 'w')
  print >> ef, 'count,user,pool,stats_missing,admission_result,state,status_type,query_status'
  for error, cnt in errors.items():
    print >> ef, '%d,%s,%s,%s,%s,%s,%s,%s' % ((cnt,) + error)
  ef.close()
  
if __name__ == '__main__':
  parser = OptionParser(
    usage='%prog <output_name> <input_dir_or_file> ...')

  parser.add_option('--impala', action='store_true',
                    dest='impala',
                    help='Capture Impala queries.')

  parser.add_option('--debug', action='store_true',
                    dest='debug',
                    help='Enable debugging output.')

  (options, args) = parser.parse_args()

  if options.debug:
    LOG.setLevel(logging.DEBUG)

  if len(args) < 2:
    parser.print_help()
    exit(1)

  # Arguments
  output_name = args[0]
  input = args[1:]

  process_input(input, output_name, options.impala)

