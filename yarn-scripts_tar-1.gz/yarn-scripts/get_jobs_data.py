#!/usr/bin/env python

from collections import Counter
from datetime import datetime, timedelta
from getpass import getpass
from optparse import OptionParser
from urllib import quote
import json
import logging
import os
import requests
import sys
import warnings

API_FETCH_LIMIT = 1000

logging.basicConfig()
LOG = logging.getLogger(sys.argv[0])

class GetJobData:

  def __init__(self, username, password, options, cm_url, output_dir, start_time, end_time):
    self.session = requests.Session()
    self.session.auth = (username, password)
    self.cm_url = cm_url.rstrip('/')
    self.output_dir = output_dir
    self.start_time = datetime.strptime(start_time, '%Y%m%d%H%M%S')
    self.end_time = datetime.strptime(end_time, '%Y%m%d%H%M%S')
    self.options = options

  def get(self, path):
    warnings.simplefilter('ignore')
    url = '%s%s' % (self.cm_url, path)
    LOG.debug('URL: %s' % (url,))
    r = self.session.get(url, verify=False)
    r.raise_for_status()
    return r.text
  
  def get_json(self, path):
    return json.loads(self.get(path))
  
  def timedelta_total_seconds(self, td):
    return int((td.microseconds + 0.0 + (td.seconds + td.days * 24 * 3600) * 10 ** 6) / 10 ** 6)
  
  def get_data(self):
    if self.options.impala:
      service_type = 'IMPALA'
      api_endpoint_name = 'impalaQueries'
      collection_name = 'queries'
      state_attribute = 'queryState'
      query_filter = 'filter=queryState!=CREATED'
      if self.options.no_describe or self.options.no_use:
        query_filter += '+and+(queryType!=DDL'
        if self.options.no_describe:
          query_filter += '+or+ddl_type!=DESCRIBE_TABLE'
        if self.options.no_use:
          query_filter += '+or+ddl_type!=USE'
        query_filter += ')'
    else:
      service_type = 'YARN'
      api_endpoint_name = 'yarnApplications'
      collection_name = 'applications'
      state_attribute = 'state'
      query_filter = 'filter=executing=false'

    # Get cluster and service details
    clusters_path = '/api/v12/clusters'
    cluster_name = quote(self.get_json(clusters_path)['items'][0]['name'])
    services_path = '/api/v12/clusters/%s/services' % (cluster_name,)
    services = self.get_json(services_path)
    service_names = map(lambda s: quote(s['name']), filter(lambda x: x['type'] == service_type, services['items']))
    
    # Create output dir
    if not os.path.exists(self.output_dir):
      os.mkdir(self.output_dir)
      
    cnt = 0
    curr = self.end_time - timedelta(hours=cnt)
    while curr >= self.start_time:
      cnt = cnt + self.options.interval_secs / 3600.0

      prev = self.end_time - timedelta(hours=cnt)
      from_time = datetime.strftime(prev, '%Y-%m-%dT%H:%M:%S.000Z')
      to_time = datetime.strftime(curr, '%Y-%m-%dT%H:%M:%S.000Z')
      print '%s:' % (to_time,)

      for service_name in service_names:
        print '  Service name: %s' % (service_name,)
        output_file = os.path.join(self.output_dir, '%s_%s.json' % (service_name, to_time,))
        apps_path = '/api/v12/clusters/%s/services/%s/%s?limit=%d&%s' % (cluster_name, service_name, api_endpoint_name, API_FETCH_LIMIT, query_filter)
        print '%s&from=%s&to=%s' % (apps_path, from_time, to_time)
        json_str = self.get('%s&from=%s&to=%s' % (apps_path, from_time, to_time))
        f = open(output_file, 'w')
        print >> f, json_str.encode('utf-8')
        f.close()
        del f

        total = 0
        for k, v in Counter(map(lambda x: x[state_attribute], json.loads(json_str)[collection_name])).items():
          print '  %6d %s' % (v, k)
          total = total + v
        print '  %6d Total' % (total,)

      curr = prev

if __name__ == '__main__':
  parser = OptionParser(
    usage='%prog <cm_url> <output_dir> <start_time> <end_time>')

  parser.add_option('--interval_secs', action='store',
                    dest='interval_secs', default=1800, type='int',
                    help='Interval, in seconds, between catpures.')

  parser.add_option('--impala', action='store_true',
                    dest='impala',
                    help='Capture Impala queries.')

  parser.add_option('--no-use', action='store_true',
                    dest='no_use',
                    help='Do not capture USE statements.')

  parser.add_option('--no-describe', action='store_true',
                    dest='no_describe',
                    help='Do not capture DESCRIBE statements.')

  parser.add_option('--debug', action='store_true',
                    dest='debug',
                    help='Enable debugging output.')

  (options, args) = parser.parse_args()

  if options.debug:
    LOG.setLevel(logging.DEBUG)

  if len(args) != 4:
    parser.print_help()
    exit(1)

  sys.stderr.write('CM username: ')
  username = sys.stdin.readline().rstrip()
  password = getpass('Password: ')
  
  yt = GetJobData(username, password, options, args[0], args[1], args[2], args[3])
  yt.get_data()

