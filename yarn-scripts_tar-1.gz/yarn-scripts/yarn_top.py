#!/usr/bin/env python

from datetime import datetime, timedelta
from getpass import getpass
from optparse import OptionParser
from subprocess import Popen, PIPE
from urllib import quote
import StringIO
import pstats
import cProfile
import curses
import json, sys
import os
import requests
import time
import warnings

API_FETCH_LIMIT = 1000
STATE_FILE = '.yarn_top.json'

class YarnTop:

  def __init__(self, username, password, cm_url, task_details, refresh):
    self.session = requests.Session()
    self.session.auth = (username, password)
    self.cm_url = cm_url.rstrip('/')
    self.task_details = task_details
    self.refresh = refresh
    self.reset_counters()

  def get_attr(self, obj, attr, dflt=''):
    if attr in obj:
      return obj[attr]
    else:
      return dflt
  
  def reset_counters(self):
    self.counters = {}

  def incr_counter(self, cats, counter, inc):
    for cat in cats:
      if type(inc) == str or type(inc) == unicode:
        if inc == '':
          inc = 0
        else:
          inc = int(inc)
      if cat not in self.counters:
        self.counters[cat] = {}
      if counter not in self.counters[cat]:
        self.counters[cat][counter] = inc
      else:
        self.counters[cat][counter] += inc
  
  def format_time(self, t):
    hours = int(t / (60*60))
    minutes = int((t - hours*60*60) / (60))
    seconds = t - hours*60*60 - minutes*60
    return '%2d:%02d:%02d' % (hours, minutes, seconds)
  
  def get(self, path):
    warnings.simplefilter("ignore")
    url = '%s%s' % (self.cm_url, path)
    r = self.session.get(url, verify=False)
    r.raise_for_status()
    return r.text
  
  def get_json(self, path):
    return json.loads(self.get(path))
  
  def timedelta_total_seconds(self, td):
    return int((td.microseconds + 0.0 + (td.seconds + td.days * 24 * 3600) * 10 ** 6) / 10 ** 6)
  
  def get_details(self):
    output = []
    self.reset_counters()
  
    # Get cluster and service details
    clusters_path = '/api/v12/clusters'
    cluster_name = quote(self.get_json(clusters_path)['items'][0]['name'])
    services_path = '/api/v12/clusters/%s/services' % (cluster_name,)
    services = self.get_json(services_path)
    service_name = quote(filter(lambda x: x["type"] == "YARN", services["items"])[0]["name"])
    apps_path = '/api/v12/clusters/%s/services/%s/yarnApplications?limit=%d' % (cluster_name, service_name, API_FETCH_LIMIT)
  
    # Print header
    row_format = '%-35s %-20s %-8s %-30s %-10s %8s %8s %8s %8s %8s %8s '
    header_columns = ('id','pool','user','name','state','pending','running','containe','complete','memory','vcores')
    if self.task_details:
      row_format = row_format + '| %8s %8s %8s | %8s %8s %8s '
      header_columns = header_columns + ('map_pend','map_run','map_comp','red_pend','red_run','red_comp')
    row_format = row_format + '%5s %9s'
    header_columns = header_columns + ('%','elapsed')
    output.append(row_format % header_columns)
  
    # Load previous state, if any
    if os.path.exists(STATE_FILE):
      old_apps = json.load(open(STATE_FILE))
    else:
      old_apps = {}
    
    # Get list of jobs
    items = self.get_json(apps_path)
    
    # Update state with the new list of jobs
    apps = {}
    for app in items['applications']:
      id = app['applicationId']
      attrs = None
      if 'endTime' in app:
        end_time = datetime.strptime(app['endTime'].replace('Z', '000'), '%Y-%m-%dT%H:%M:%S.%f')
        if end_time < datetime.utcnow() - timedelta(seconds=30):
          continue
      if id in old_apps:
        apps[id] = old_apps[id]
        attrs = apps[id]['attributes']
        attrs.update(app['attributes'])
        apps[id].update(app)
        apps[id]['attributes'] = attrs
      else:
        apps[id] = app
    
    if len(apps) == 0:
      output.append('There are no running YARN jobs at the moment')
    else:
      for app in sorted(apps.values(), lambda x, y: cmp('%08d%s'%(self.get_attr(y, 'runningContainers', 0),y['name']), '%08d%s'%(self.get_attr(x, 'runningContainers', 0),x['name']))):
        pool = app['pool']
        start_time = datetime.strptime(app['startTime'].replace('Z', '000'), '%Y-%m-%dT%H:%M:%S.%f')
        end_time = datetime.utcnow()
        elapsed_time = self.timedelta_total_seconds(end_time - start_time)
        progress = self.get_attr(app, 'progress', '')
        us = self.get_attr(app['attributes'], 'hive_sentry_subject_name', self.get_attr(app, 'user'))[:8]
        tp = self.get_attr(app['attributes'], 'tasks_pending')
        tr = self.get_attr(app['attributes'], 'tasks_running')
        tc = self.get_attr(app['attributes'], 'tasks_completed')
        mp = self.get_attr(app['attributes'], 'maps_pending')
        mr = self.get_attr(app['attributes'], 'maps_running')
        mc = self.get_attr(app['attributes'], 'maps_completed')
        rp = self.get_attr(app['attributes'], 'reduces_pending')
        rr = self.get_attr(app['attributes'], 'reduces_running')
        rc = self.get_attr(app['attributes'], 'reduces_completed')
        co = self.get_attr(app, 'runningContainers', 0)
        am = self.get_attr(app, 'allocatedMB', '')
        ac = self.get_attr(app, 'allocatedVCores', '')
        output.append(row_format % ((
          app['applicationId'],
          pool,
          us,
          app['name'].replace('\n', ' ').replace('\t', ' ')[0:30],
          app['state'],
          tp, tr, co, tc, am, ac
        ) +
        ((mp, mr, mc, rp, rr, rc) if self.task_details else ()) +
        (
          '%5.1f' % (progress,) if progress != '' else '',
          self.format_time(elapsed_time),
        )))
        self.incr_counter(['total', pool], 'pending', tp)
        self.incr_counter(['total', pool], 'running', tr)
        self.incr_counter(['total', pool], 'complete', tc)
        self.incr_counter(['total', pool], 'maps_pending', mp)
        self.incr_counter(['total', pool], 'maps_running', mr)
        self.incr_counter(['total', pool], 'maps_complete', mc)
        self.incr_counter(['total', pool], 'reduces_pending', rp)
        self.incr_counter(['total', pool], 'reduces_running', rr)
        self.incr_counter(['total', pool], 'reduces_complete', rc)
        self.incr_counter(['total', pool], 'containers', co)
        self.incr_counter(['total', pool], 'memory', am)
        self.incr_counter(['total', pool], 'vcores', ac)
      
      c = self.counters['total']
      output.append(row_format % (('','','','','',c['pending'],c['running'],c['containers'],c['complete'],c['memory'],c['vcores']) +
        ((c['maps_pending'],c['maps_running'],c['maps_complete'],c['reduces_pending'],c['reduces_running'],c['reduces_complete']) if self.task_details else ()) +
        ('', '')))
      output.append('')
      
      output.append('%-20s %8s %8s %8s %8s %8s %8s' % ('pool','pending','running','containe','complete','memory','vcores'))
      for pool, c in sorted(self.counters.items(), lambda x, y: cmp(y[1]['containers'], x[1]['containers'])):
        if pool == 'total':
          continue
        output.append('%-20s %8s %8s %8s %8s %8s %8s' % (pool,c['pending'],c['running'],c['containers'],c['complete'],c['memory'],c['vcores']))
      
    json.dump(apps, open(STATE_FILE,'w'))
  
    return '\n'.join(output)
  
  def main(self, stdscr):
    curses.curs_set(0)
    height, width = stdscr.getmaxyx()
    try:
      while True:
        stdscr.clear()
        output = datetime.strftime(datetime.now(), '%c')
        output = ' ' * (width - len(output)) + output + '\n' + self.get_details()
        stdscr.addstr(output)
        stdscr.refresh()
        time.sleep(self.refresh)
    except KeyboardInterrupt:
      pass
    
  def top(self):
    if self.refresh == 0:
      print self.get_details()
    else:
      curses.wrapper(self.main)
  
if __name__ == '__main__':
  parser = OptionParser(
    usage='%prog <cm_url>')

  parser.add_option('--task-details', action='store_true',
                    dest='task_details', default=False,
                    help='Show mapper/reducer tasks\' details')

  (options, args) = parser.parse_args()

  if len(args) < 1:
    parser.print_help()
    exit(1)

  sys.stderr.write("CM username: ")
  username = sys.stdin.readline().rstrip()
  password = getpass("Password: ")
  
  if len(args) == 2 and args[1][:7] == 'refresh':
    refresh = int(args[1][8:])
  else:
    refresh = 0

#  pr = cProfile.Profile()
#  pr.enable()

  yt = YarnTop(username, password, args[0], options.task_details, refresh)
  yt.top()

#  pr.disable()
#  s = StringIO.StringIO()
#  sortby = 'cumulative'
#  ps = pstats.Stats(pr, stream=s).sort_stats(sortby)
#  ps.print_stats()
#  print s.getvalue()

