#!/usr/bin/env python

from math import log10
from optparse import OptionParser
import numpy as np
import sys

def _sort_buckets_by_bands(b1, b2):
  b1_small = sum(map(lambda x: x[1] if x[0] <= 5 else 0, b1[1].items()))
  b2_small = sum(map(lambda x: x[1] if x[0] <= 5 else 0, b2[1].items()))
  return cmp(b2_small, b1_small)
  
def _make_sort_buckets_by_sizes(threshold):
  def _sort_buckets_by_sizes(b1, b2):
    b1_small = (np.array(b1[1]) < threshold).sum()
    b2_small = (np.array(b2[1]) < threshold).sum()
    return cmp(b2_small, b1_small)
  return _sort_buckets_by_sizes
  
def generate_report(base, level, threshold):
  baselen = len(base)
  bands = {}
  sizes = {}
  for line in sys.stdin:
    if line[0:baselen] == base and 'bytes,' in line:
      fields = line.split(' ')

      # Get bucket name
      pos = baselen-1
      for i in range(0,level):
        pos = fields[0].find('/', pos+1)
      bucket = fields[0][0:pos+1]
      if bucket not in sizes:
        sizes[bucket] = []
        bands[bucket] = {}
  
      # Get file size and path
      if fields[2] == 'bytes,':
        size_bytes = int(fields[1])
        file_path = fields[0]
      else:
        for p in range(3,len(fields)):
          if fields[p] == 'bytes,':
            size_bytes = int(fields[p-1])
            file_path = ' '.join(fields[0:p-1])
            break
        
      sizes[bucket].append(size_bytes)
      if size_bytes == 0:
        b = -1
      else:
        b = int(log10(size_bytes))
      if b in bands[bucket]:
        bands[bucket][b] += 1
      else:
        bands[bucket][b] = 1
  
  if threshold is not None:
    print "{0:<130s} {1:>20s} {2:>20s} {3:>10s} {4:>5s}%".format('directory','total_sz_bytes','median_sz_bytes','smallfiles','% of total files')
    for bucket, bkt_sizes in sorted(sizes.items(), _make_sort_buckets_by_sizes(threshold)):
      all_cnt = len(bkt_sizes)
      small_cnt = (np.array(sizes[bucket]) < threshold).sum()
      print "{0:<130s} {1:>20,.0f} {2:>20,.0f} {3:>10,.0f} {4:>5,.1f}%".format(bucket, sum(sizes[bucket]), np.median(sizes[bucket]), small_cnt, 100.0*small_cnt/all_cnt)
  else:
    for bucket, bkt_bands in sorted(bands.items(), _sort_buckets_by_bands):
      all_cnt = len(sizes[bucket])
      print "\nDirectory: %s" % (bucket,)
      print "Count:       {0:,}".format(all_cnt)
      print "Total size:  {0:,}".format(sum(sizes[bucket]))
      print "Mean size:   {0:,.0f}".format(np.mean(sizes[bucket]))
      print "Median size: {0:,.0f}".format(np.median(sizes[bucket]))
      print "{0:>35s} {1:>15s} {2:>10s} {3:>15s} {4:>10s}".format("Bytes", "Files", "Pct", "Running sum", "Running pct")
      running_cnt = 0
      for b in sorted(bkt_bands.keys()):
        band_cnt = bkt_bands[b]
        running_cnt += band_cnt
        print "{0:>35s} {1:>15,d} {2:>10,.1f} {3:>15,d} {4:>10,.1f}".format("0" if b == -1 else "{0:,.0f} to {1:,.0f}".format(pow(10,b), pow(10,b+1)-1),
          band_cnt, 100.0*band_cnt/all_cnt, running_cnt, 100.0*running_cnt/all_cnt)

class HdfsDir:
  def __init__(self, path):
    self.path = path
    self.parent = path[:path[:-1].rfind('/')+1]
    self.file_sizes = []

def all_dirs(report_date):
  dirs = {}
  for line in sys.stdin:
    if 'bytes,' in line:
      fields = line.split(' ')

      # Get file size and path
      if fields[2] == 'bytes,':
        size_bytes = int(fields[1])
        file_path = fields[0]
      else:
        for p in range(3,len(fields)):
          if fields[p] == 'bytes,':
            size_bytes = int(fields[p-1])
            file_path = ' '.join(fields[0:p-1])
      dir_path = file_path[:file_path.rfind('/')+1]
        
      pos = 0
      while pos != -1:
        d = dir_path[0:pos+1]
        if d not in dirs:
          dirs[d] = HdfsDir(d)
        dir = dirs[d]
        dir.file_sizes.append(size_bytes)
 
        pos = dir_path.find('/', pos+1)
  
  for path, dir in dirs.items():
    file_sizes = np.array(dir.file_sizes)
    print "%s,%s,%s,%d,%d,%d,%d,%d,%d,%d" % (
      report_date,
      dir.path,
      dir.parent,
      len(file_sizes),
      np.sum(file_sizes < 1000000),
      np.sum(file_sizes < 10000000),
      np.sum(file_sizes < 100000000),
      np.mean(file_sizes),
      np.median(file_sizes),
      np.sum(file_sizes))

if __name__ == '__main__':
  parser = OptionParser(
    usage='%prog <base_dir> <level>')

  parser.add_option('--one-line-report', action='store', type='int',
                    dest='threshold_bytes', default=None,
                    metavar='THRESHOLD_BYTES',
                    help='Small file threshold, in bytes')
  
  parser.add_option('--all-dirs', action='store',
                    dest='report_date', default=None,
                    metavar='REPORT_DATE(YYYY-MM-DD)',
                    help='Generate special reports for all dirs')
  
  (options, args) = parser.parse_args()

  if len(args) != 2:
    parser.print_help()
    exit(1)

  base = args[0]
  if base[-1] != '/':
    base = base + '/'
  level = int(args[1])
  if options.report_date is not None:
    all_dirs(options.report_date)
  else:
    generate_report(base, level, options.threshold_bytes)
