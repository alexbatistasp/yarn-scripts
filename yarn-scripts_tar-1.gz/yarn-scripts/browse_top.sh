#!/bin/bash

function format_time {
  local time=$1
  local hours=$((time/1000/60/60))
  local minutes=$(((time-hours*1000*60*60)/1000/60))
  local seconds=$(((time-hours*1000*60*60-minutes*1000*60)/1000))
  printf "%d:%02d:%02d" $hours $minutes $seconds
}

if [ $# -lt 1 ]; then
  echo "Usage: $0 <output_name> [number_of_queries]"
  exit 1
fi

BASE_NAME=$1
TOP=${2:-10}

STATS_FILE=${BASE_NAME}_stats.csv

echo ""
PS3="Choose a counter: "
select COUNTER_NAME in $( head -1 $STATS_FILE | sed 's/,/ /g' ); do
  if [ "$COUNTER_NAME" != "" ]; then
    break
  fi
done
POS=$((REPLY+1))

echo ""
PS3="Sort by which type of statistic? "
select STAT_TYPE in Total Average; do
  if [ "$STAT_TYPE" != "" ]; then
    break
  fi
done
SORT=$((3+REPLY))

echo -e "\n\n"
for LINE in $( sed 's/,/A/g' $STATS_FILE | grep -v elapsed_time | awk -FA '$'$POS'!=""{printf "%sA%dA%dA%dA%d\n", $1, $2, $4, $'$POS', $'$POS'/$4}' | sort -tA -k$SORT -nr | head -$TOP | sed 's/A/,/g' ); do
  echo "$LINE"
  DIGEST=$( echo "$LINE" | awk -F, '{print $1}' )
  TOTAL_ELAPSED_TIME=$( echo "$LINE" | awk -F, '{print $2}' | sed 's/\..*//' )
  EXECUTIONS=$( echo "$LINE" | awk -F, '{print $3}' | sed 's/\..*//' )
  TOTAL_COUNTER_VALUE=$( echo "$LINE" | awk -F, '{print $4}' )
  AVG_COUNTER_VALUE=$( echo "$LINE" | awk -F, '{print $5}' )

  echo "=============================================================================================================================="
  echo "Digest: $DIGEST"
  echo ""

  echo "User: $( cat $BASE_NAME/$DIGEST/users.txt )"
  echo "Pool: $( cat $BASE_NAME/$DIGEST/pools.txt )"
  echo "Executions: $EXECUTIONS"
  echo "Total elapsed time: $(format_time $TOTAL_ELAPSED_TIME)"
  echo "Average elapsed time: $(format_time $((TOTAL_ELAPSED_TIME/EXECUTIONS)))"
  if [ "$COUNTER_NAME" != "elapsed_time" -a "$COUNTER_NAME" != "instances" ]; then
    echo "Counter $COUNTER_NAME:"
    printf "  Total:   %15.3f\n" $TOTAL_COUNTER_VALUE
    printf "  Average: %15.3f\n" $AVG_COUNTER_VALUE
  fi
  echo "Query sample:"

  echo ""

  find $BASE_NAME/$DIGEST ! -name "*json" -name "*[0-9]*" -type f | head -1 | xargs cat

  echo -e "\n\n"

  echo -n "Next..."
  read -s DUMMY
  echo -en "\r"
done
